import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./app/**/*.{ts,tsx}",
    "./components/**/*.{ts,tsx}",
    "./lib/**/*.{ts,tsx}"
  ],
  theme: {
    extend: {
      colors: {
        cream: "#f7f2ea",
        sand: "#efe6da",
        ink: "#312d2a",
        taupe: "#8a7f76",
        blush: "#edd8d2",
        sage: "#d8e3d5",
        accent: "#a58b74"
      },
      boxShadow: {
        soft: "0 10px 30px rgba(49,45,42,0.08)",
        card: "0 14px 40px rgba(49,45,42,0.10)"
      },
      borderRadius: {
        "4xl": "2rem"
      },
      backgroundImage: {
        "soft-radial": "radial-gradient(circle at top, rgba(255,255,255,0.95), rgba(247,242,234,1) 55%, rgba(239,230,218,1))"
      }
    }
  },
  plugins: []
};

export default config;
