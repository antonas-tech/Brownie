# Dinasty

Mobile-first PWA for a private family social network / memory archive.

## Start locally

```bash
npm install
cp .env.example .env.local
# fill env vars
npm run dev
```

## Supabase

1. Create project.
2. Run `supabase/schema.sql` in SQL Editor.
3. Enable Email auth.
4. Enable Realtime for `posts`, `comments`, `stories`, `messages`.
5. Put URL and anon key into `.env.local`.

## PM2 deploy

```bash
sudo apt update && sudo apt install -y nginx curl git
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs
sudo npm install -g pm2

git clone <your-repo-url> dinasty
cd dinasty
npm install
cp .env.example .env.local
nano .env.local
npm run build
pm2 start npm --name dinasty -- start
pm2 save
pm2 startup
```

Nginx config:

```nginx
server {
    listen 80;
    server_name your-domain.com;

    location / {
        proxy_pass http://127.0.0.1:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

Enable:

```bash
sudo ln -s /etc/nginx/sites-available/dinasty /etc/nginx/sites-enabled/dinasty
sudo nginx -t
sudo systemctl restart nginx
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d your-domain.com
```
