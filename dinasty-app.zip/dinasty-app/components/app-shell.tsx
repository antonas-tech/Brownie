"use client";

import { BottomNav, TabKey } from "@/components/bottom-nav";
import { FeedPanel } from "@/components/feed-panel";
import { MessagesPanel } from "@/components/messages-panel";
import { ProfilePanel } from "@/components/profile-panel";
import { StoriesPanel } from "@/components/stories-panel";
import { supabase } from "@/lib/supabase";
import { Profile } from "@/lib/types";
import { motion } from "framer-motion";
import { Crown, Sparkles } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

export function AppShell() {
  const [activeTab, setActiveTab] = useState<TabKey>("feed");
  const [profile, setProfile] = useState<Profile | null>(null);
  const [authUserId, setAuthUserId] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);

  async function loadSession() {
    const {
      data: { session }
    } = await supabase.auth.getSession();

    const userId = session?.user?.id ?? null;
    setAuthUserId(userId);

    if (userId) {
      const { data } = await supabase.from("profiles").select("*").eq("id", userId).single();
      setProfile((data as Profile) ?? null);
    } else {
      setProfile(null);
    }
    setLoading(false);
  }

  useEffect(() => {
    loadSession();

    const {
      data: { subscription }
    } = supabase.auth.onAuthStateChange(() => {
      loadSession();
    });

    return () => subscription.unsubscribe();
  }, []);

  const subtitle = useMemo(() => {
    if (!profile) return "Семейный архив для тёплых воспоминаний";
    return `Добро пожаловать, ${profile.nickname}`;
  }, [profile]);

  return (
    <main className="mx-auto min-h-screen max-w-md px-3 pb-28 pt-4">
      <motion.header
        initial={{ opacity: 0, y: 16 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-4 rounded-[32px] bg-soft-radial p-5 shadow-soft"
      >
        <div className="mb-3 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-3xl bg-white/70 shadow-soft">
              <Crown className="h-6 w-6 text-accent" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">Dinasty</h1>
              <p className="text-sm text-taupe">{subtitle}</p>
            </div>
          </div>
          <div className="rounded-full bg-white/70 p-2 text-accent shadow-soft">
            <Sparkles className="h-5 w-5" />
          </div>
        </div>
      </motion.header>

      <div className="space-y-4">
        {activeTab === "feed" && (
          <FeedPanel authUserId={authUserId} profile={profile} loading={loading} />
        )}
        {activeTab === "stories" && (
          <StoriesPanel authUserId={authUserId} profile={profile} loading={loading} />
        )}
        {activeTab === "messages" && (
          <MessagesPanel authUserId={authUserId} profile={profile} loading={loading} />
        )}
        {activeTab === "profile" && (
          <ProfilePanel authUserId={authUserId} profile={profile} loading={loading} />
        )}
      </div>

      <BottomNav active={activeTab} onChange={setActiveTab} />
    </main>
  );
}
