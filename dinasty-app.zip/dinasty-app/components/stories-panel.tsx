"use client";

import { Button, Input, SectionCard, Textarea } from "@/components/ui";
import { StoryItem, Profile } from "@/lib/types";
import { supabase, uploadFile } from "@/lib/supabase";
import { formatDate } from "@/lib/utils";
import { motion } from "framer-motion";
import Image from "next/image";
import { BookHeart, ImagePlus } from "lucide-react";
import { useEffect, useState } from "react";

function StoryCard({ story }: { story: StoryItem }) {
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      className="overflow-hidden rounded-[30px] bg-white/72 shadow-soft"
    >
      {story.image_url && (
        <div className="relative h-56 w-full">
          <Image src={story.image_url} alt={story.title} fill className="object-cover" sizes="100vw" />
        </div>
      )}
      <div className="space-y-3 p-4">
        <div className="flex items-start justify-between gap-3">
          <div>
            <p className="text-lg font-semibold">{story.title}</p>
            <p className="text-sm text-taupe">
              {story.profiles?.nickname ?? "Автор"} • {formatDate(story.created_at)}
            </p>
          </div>
          <div className="rounded-full bg-blush px-3 py-1 text-xs text-ink">Архив</div>
        </div>
        <p className="whitespace-pre-wrap text-sm leading-7 text-ink/90">{story.body}</p>
      </div>
    </motion.article>
  );
}

export function StoriesPanel({
  authUserId,
  profile,
  loading
}: {
  authUserId: string | null;
  profile: Profile | null;
  loading: boolean;
}) {
  const [stories, setStories] = useState<StoryItem[]>([]);
  const [title, setTitle] = useState("");
  const [body, setBody] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [pending, setPending] = useState(false);

  async function loadStories() {
    const { data } = await supabase
      .from("stories")
      .select("*, profiles:author_id(*)")
      .order("created_at", { ascending: false });

    setStories((data as StoryItem[]) ?? []);
  }

  useEffect(() => {
    loadStories();

    const channel = supabase
      .channel("stories-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "stories" },
        () => loadStories()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  async function createStory() {
    if (!authUserId || !title.trim() || !body.trim()) return;
    setPending(true);

    let imageUrl: string | null = null;
    if (image) {
      imageUrl = await uploadFile("stories", image, authUserId);
    }

    await supabase.from("stories").insert({
      author_id: authUserId,
      title: title.trim(),
      body: body.trim(),
      image_url: imageUrl
    });

    setTitle("");
    setBody("");
    setImage(null);
    setPending(false);
    await loadStories();
  }

  return (
    <div className="space-y-4">
      <SectionCard className="space-y-3">
        <div className="flex items-center gap-3">
          <div className="rounded-3xl bg-white/75 p-3">
            <BookHeart className="h-5 w-5 text-accent" />
          </div>
          <div>
            <p className="text-lg font-semibold">Семейные истории</p>
            <p className="text-sm text-taupe">
              Личный архив смешных, нежных и важных воспоминаний.
            </p>
          </div>
        </div>

        {authUserId ? (
          <>
            <Input
              placeholder="Название истории"
              value={title}
              onChange={(e) => setTitle(e.target.value)}
            />
            <Textarea
              placeholder={profile ? `${profile.nickname}, расскажите эту историю красиво…` : "Расскажите историю…"}
              value={body}
              onChange={(e) => setBody(e.target.value)}
            />
            <label className="flex cursor-pointer items-center gap-3 rounded-3xl border border-dashed border-white/80 bg-white/60 p-4 text-sm text-taupe">
              <ImagePlus className="h-5 w-5" />
              <span>{image ? image.name : "Добавить фото к истории"}</span>
              <input
                className="hidden"
                type="file"
                accept="image/*"
                onChange={(e) => setImage(e.target.files?.[0] ?? null)}
              />
            </label>
            <Button onClick={createStory} disabled={pending || !title.trim() || !body.trim()}>
              {pending ? "Сохраняем…" : "Сохранить историю"}
            </Button>
          </>
        ) : (
          <p className="rounded-3xl bg-white/60 p-4 text-sm text-taupe">
            Авторизуйтесь, чтобы добавить историю в семейный архив.
          </p>
        )}
      </SectionCard>

      {loading && stories.length === 0 ? (
        <SectionCard>Загружаем архив…</SectionCard>
      ) : (
        <div className="space-y-4">
          {stories.map((story) => (
            <StoryCard key={story.id} story={story} />
          ))}
        </div>
      )}
    </div>
  );
}
