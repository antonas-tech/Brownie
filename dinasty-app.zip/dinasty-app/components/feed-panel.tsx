"use client";

import { Button, Input, SectionCard, Textarea } from "@/components/ui";
import { supabase, uploadFile } from "@/lib/supabase";
import { CommentItem, Post, Profile } from "@/lib/types";
import { formatDate } from "@/lib/utils";
import { motion } from "framer-motion";
import Image from "next/image";
import { ImagePlus, MessageCircleMore, SendHorizonal } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

function CommentComposer({
  postId,
  authUserId,
  onCreated
}: {
  postId: string;
  authUserId: string;
  onCreated: () => Promise<void>;
}) {
  const [content, setContent] = useState("");
  const [pending, setPending] = useState(false);

  async function submit() {
    if (!content.trim()) return;
    setPending(true);
    await supabase.from("comments").insert({
      post_id: postId,
      author_id: authUserId,
      content: content.trim()
    });
    setContent("");
    setPending(false);
    await onCreated();
  }

  return (
    <div className="mt-3 flex items-center gap-2">
      <Input
        placeholder="Ваш комментарий…"
        value={content}
        onChange={(e) => setContent(e.target.value)}
        className="py-2.5"
      />
      <Button onClick={submit} disabled={pending || !content.trim()} className="px-3">
        <SendHorizonal className="h-4 w-4" />
      </Button>
    </div>
  );
}

function PostCard({
  post,
  authUserId,
  refresh
}: {
  post: Post & { comments: CommentItem[] };
  authUserId: string | null;
  refresh: () => Promise<void>;
}) {
  return (
    <motion.article
      layout
      initial={{ opacity: 0, y: 14 }}
      animate={{ opacity: 1, y: 0 }}
      className="rounded-[30px] bg-white/72 p-4 shadow-soft"
    >
      <div className="mb-3 flex items-center gap-3">
        <div className="relative h-11 w-11 overflow-hidden rounded-2xl bg-sand">
          {post.profiles?.avatar_url ? (
            <Image src={post.profiles.avatar_url} alt="" fill className="object-cover" sizes="44px" />
          ) : null}
        </div>
        <div className="min-w-0">
          <p className="truncate text-sm font-semibold">{post.profiles?.nickname ?? "Участник семьи"}</p>
          <p className="text-xs text-taupe">{formatDate(post.created_at)}</p>
        </div>
      </div>

      <p className="whitespace-pre-wrap text-[15px] leading-7">{post.content}</p>

      {post.image_url && (
        <div className="relative mt-3 h-64 overflow-hidden rounded-[26px]">
          <Image src={post.image_url} alt="" fill className="object-cover" sizes="(max-width: 768px) 100vw, 500px" />
        </div>
      )}

      <div className="mt-4 flex items-center gap-2 text-sm text-taupe">
        <MessageCircleMore className="h-4 w-4" />
        {post.comments.length} комментариев
      </div>

      <div className="mt-3 space-y-2">
        {post.comments.map((comment) => (
          <div key={comment.id} className="rounded-3xl bg-cream px-4 py-3">
            <p className="text-xs font-medium text-taupe">
              {comment.profiles?.nickname ?? "Участник"} • {formatDate(comment.created_at)}
            </p>
            <p className="mt-1 text-sm leading-6">{comment.content}</p>
          </div>
        ))}
      </div>

      {authUserId && (
        <CommentComposer postId={post.id} authUserId={authUserId} onCreated={refresh} />
      )}
    </motion.article>
  );
}

export function FeedPanel({
  authUserId,
  profile,
  loading
}: {
  authUserId: string | null;
  profile: Profile | null;
  loading: boolean;
}) {
  const [posts, setPosts] = useState<Array<Post & { comments: CommentItem[] }>>([]);
  const [content, setContent] = useState("");
  const [image, setImage] = useState<File | null>(null);
  const [pending, setPending] = useState(false);

  async function loadFeed() {
    const { data } = await supabase
      .from("posts")
      .select("*, profiles:author_id (*), comments(*, profiles:author_id(*))")
      .order("created_at", { ascending: false });

    setPosts(((data as Array<Post & { comments: CommentItem[] }>) ?? []).map((post) => ({
      ...post,
      comments: [...(post.comments ?? [])].sort((a, b) =>
        a.created_at.localeCompare(b.created_at)
      )
    })));
  }

  useEffect(() => {
    loadFeed();

    const channel = supabase
      .channel("feed-realtime")
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "posts" },
        () => loadFeed()
      )
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "comments" },
        () => loadFeed()
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, []);

  async function createPost() {
    if (!authUserId || !content.trim()) return;

    setPending(true);
    let imageUrl: string | null = null;

    if (image) {
      imageUrl = await uploadFile("posts", image, authUserId);
    }

    await supabase.from("posts").insert({
      author_id: authUserId,
      content: content.trim(),
      image_url: imageUrl
    });

    setContent("");
    setImage(null);
    setPending(false);
    await loadFeed();
  }

  const header = useMemo(
    () => (profile ? `Поделитесь моментом, ${profile.nickname}` : "Лента семьи в реальном времени"),
    [profile]
  );

  return (
    <div className="space-y-4">
      <SectionCard className="space-y-3">
        <div>
          <p className="text-lg font-semibold">{header}</p>
          <p className="text-sm text-taupe">
            Фото, воспоминания, семейные новости и живые комментарии.
          </p>
        </div>

        {authUserId ? (
          <>
            <Textarea
              placeholder="Что нового в семье?"
              value={content}
              onChange={(e) => setContent(e.target.value)}
            />
            <label className="flex cursor-pointer items-center gap-3 rounded-3xl border border-dashed border-white/80 bg-white/60 p-4 text-sm text-taupe">
              <ImagePlus className="h-5 w-5" />
              <span>{image ? image.name : "Добавить фото к посту"}</span>
              <input
                className="hidden"
                type="file"
                accept="image/*"
                onChange={(e) => setImage(e.target.files?.[0] ?? null)}
              />
            </label>
            <Button onClick={createPost} disabled={pending || !content.trim()}>
              {pending ? "Публикуем…" : "Опубликовать"}
            </Button>
          </>
        ) : (
          <p className="rounded-3xl bg-white/60 p-4 text-sm text-taupe">
            Войдите в аккаунт, чтобы публиковать посты и оставлять комментарии.
          </p>
        )}
      </SectionCard>

      {loading && posts.length === 0 ? (
        <SectionCard>Загружаем ленту…</SectionCard>
      ) : (
        posts.map((post) => (
          <PostCard key={post.id} post={post} authUserId={authUserId} refresh={loadFeed} />
        ))
      )}
    </div>
  );
}
