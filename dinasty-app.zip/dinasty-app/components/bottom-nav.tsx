import { cn } from "@/lib/utils";
import { AnimatePresence, motion } from "framer-motion";
import { Home, MessageCircleMore, ScrollText, UserRound } from "lucide-react";

export type TabKey = "feed" | "stories" | "messages" | "profile";

const ITEMS: Array<{
  key: TabKey;
  label: string;
  icon: React.ComponentType<{ className?: string }>;
}> = [
  { key: "feed", label: "Лента", icon: Home },
  { key: "stories", label: "Истории", icon: ScrollText },
  { key: "messages", label: "Чаты", icon: MessageCircleMore },
  { key: "profile", label: "Профиль", icon: UserRound }
];

export function BottomNav({
  active,
  onChange
}: {
  active: TabKey;
  onChange: (tab: TabKey) => void;
}) {
  return (
    <div className="fixed bottom-4 left-1/2 z-50 w-[calc(100%-24px)] max-w-md -translate-x-1/2 px-1">
      <nav className="glass card-border relative grid grid-cols-4 rounded-[28px] p-2 shadow-card">
        {ITEMS.map((item) => {
          const Icon = item.icon;
          const isActive = active === item.key;

          return (
            <button
              key={item.key}
              onClick={() => onChange(item.key)}
              className={cn(
                "relative z-10 flex flex-col items-center justify-center gap-1 rounded-3xl px-2 py-3 text-[11px] font-medium transition",
                isActive ? "text-ink" : "text-taupe"
              )}
            >
              <AnimatePresence>
                {isActive && (
                  <motion.span
                    layoutId="nav-pill"
                    className="absolute inset-0 -z-10 rounded-3xl bg-white/85"
                    transition={{ type: "spring", stiffness: 350, damping: 28 }}
                  />
                )}
              </AnimatePresence>
              <Icon className="h-5 w-5" />
              {item.label}
            </button>
          );
        })}
      </nav>
    </div>
  );
}
