"use client";

import { Button, Input, SectionCard } from "@/components/ui";
import { supabase } from "@/lib/supabase";
import { ChatRoom, MessageItem, Profile } from "@/lib/types";
import { cn, formatDate } from "@/lib/utils";
import { motion } from "framer-motion";
import { MessagesSquare, Plus, SendHorizonal } from "lucide-react";
import { useEffect, useMemo, useState } from "react";

type RoomWithLast = ChatRoom & {
  last_message?: string;
};

export function MessagesPanel({
  authUserId,
  profile,
  loading
}: {
  authUserId: string | null;
  profile: Profile | null;
  loading: boolean;
}) {
  const [rooms, setRooms] = useState<RoomWithLast[]>([]);
  const [activeRoomId, setActiveRoomId] = useState<string | null>(null);
  const [messages, setMessages] = useState<MessageItem[]>([]);
  const [roomTitle, setRoomTitle] = useState("");
  const [roomInvites, setRoomInvites] = useState("");
  const [messageText, setMessageText] = useState("");

  async function loadRooms() {
    if (!authUserId) {
      setRooms([]);
      return;
    }

    const { data: memberships } = await supabase
      .from("chat_room_members")
      .select("room_id")
      .eq("user_id", authUserId);

    const roomIds = memberships?.map((item) => item.room_id) ?? [];
    if (roomIds.length === 0) {
      setRooms([]);
      return;
    }

    const { data: roomsData } = await supabase
      .from("chat_rooms")
      .select("*")
      .in("id", roomIds)
      .order("created_at", { ascending: false });

    const enriched: RoomWithLast[] = [];
    for (const room of roomsData ?? []) {
      const { data: last } = await supabase
        .from("messages")
        .select("content")
        .eq("room_id", room.id)
        .order("created_at", { ascending: false })
        .limit(1)
        .maybeSingle();

      enriched.push({
        ...(room as ChatRoom),
        last_message: last?.content
      });
    }

    setRooms(enriched);

    if (!activeRoomId && enriched[0]) {
      setActiveRoomId(enriched[0].id);
    }
  }

  async function loadMessages(roomId: string) {
    const { data } = await supabase
      .from("messages")
      .select("*, profiles:author_id(*)")
      .eq("room_id", roomId)
      .order("created_at", { ascending: true });

    setMessages((data as MessageItem[]) ?? []);
  }

  useEffect(() => {
    loadRooms();
  }, [authUserId]);

  useEffect(() => {
    if (!activeRoomId) {
      setMessages([]);
      return;
    }

    loadMessages(activeRoomId);

    const channel = supabase
      .channel(`room-${activeRoomId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "messages", filter: `room_id=eq.${activeRoomId}` },
        () => loadMessages(activeRoomId)
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [activeRoomId]);

  async function createRoom() {
    if (!authUserId || !roomTitle.trim()) return;

    const { data: roomData, error } = await supabase
      .from("chat_rooms")
      .insert({
        title: roomTitle.trim(),
        is_group: true,
        created_by: authUserId
      })
      .select()
      .single();

    if (error || !roomData) return;

    const members = [authUserId];
    if (roomInvites.trim()) {
      const usernames = roomInvites
        .split(",")
        .map((item) => item.trim().replace("@", "").toLowerCase())
        .filter(Boolean);

      if (usernames.length > 0) {
        const { data: profiles } = await supabase
          .from("profiles")
          .select("id, username")
          .in("username", usernames);

        members.push(...((profiles ?? []).map((item) => item.id)));
      }
    }

    await supabase.from("chat_room_members").insert(
      Array.from(new Set(members)).map((userId) => ({
        room_id: roomData.id,
        user_id: userId
      }))
    );

    setRoomTitle("");
    setRoomInvites("");
    await loadRooms();
    setActiveRoomId(roomData.id);
  }

  async function sendMessage() {
    if (!authUserId || !activeRoomId || !messageText.trim()) return;

    await supabase.from("messages").insert({
      room_id: activeRoomId,
      author_id: authUserId,
      content: messageText.trim()
    });

    setMessageText("");
    await loadRooms();
  }

  const activeRoom = useMemo(
    () => rooms.find((room) => room.id === activeRoomId) ?? null,
    [rooms, activeRoomId]
  );

  if (loading) return <SectionCard>Загрузка чатов…</SectionCard>;

  if (!authUserId || !profile) {
    return (
      <SectionCard>
        Войдите в аккаунт, чтобы создавать комнаты и общаться с семьёй в реальном времени.
      </SectionCard>
    );
  }

  return (
    <div className="space-y-4">
      <SectionCard className="space-y-3">
        <div className="flex items-center gap-3">
          <div className="rounded-3xl bg-white/75 p-3">
            <MessagesSquare className="h-5 w-5 text-accent" />
          </div>
          <div>
            <p className="text-lg font-semibold">Семейные комнаты</p>
            <p className="text-sm text-taupe">
              Создавайте личные и групповые чаты. Приглашения — через @username, через запятую.
            </p>
          </div>
        </div>

        <Input
          placeholder="Название комнаты"
          value={roomTitle}
          onChange={(e) => setRoomTitle(e.target.value)}
        />
        <Input
          placeholder="@anna, @mama, @ivan"
          value={roomInvites}
          onChange={(e) => setRoomInvites(e.target.value)}
        />
        <Button onClick={createRoom} disabled={!roomTitle.trim()} className="gap-2">
          <Plus className="h-4 w-4" />
          Создать комнату
        </Button>
      </SectionCard>

      <SectionCard className="p-2">
        <div className="grid grid-cols-[124px_1fr] gap-2">
          <div className="space-y-2">
            {rooms.length === 0 ? (
              <div className="rounded-[24px] bg-white/70 p-3 text-sm text-taupe">
                Комнат пока нет.
              </div>
            ) : (
              rooms.map((room) => (
                <button
                  key={room.id}
                  onClick={() => setActiveRoomId(room.id)}
                  className={cn(
                    "w-full rounded-[24px] p-3 text-left transition",
                    activeRoomId === room.id ? "bg-ink text-white" : "bg-white/70 text-ink"
                  )}
                >
                  <p className="line-clamp-2 text-sm font-semibold">{room.title}</p>
                  <p
                    className={cn(
                      "mt-1 line-clamp-2 text-xs",
                      activeRoomId === room.id ? "text-white/70" : "text-taupe"
                    )}
                  >
                    {room.last_message || "Новый чат"}
                  </p>
                </button>
              ))
            )}
          </div>

          <div className="flex min-h-[420px] flex-col rounded-[28px] bg-white/72 p-3">
            {activeRoom ? (
              <>
                <div className="border-b border-sand px-2 pb-3">
                  <p className="text-base font-semibold">{activeRoom.title}</p>
                  <p className="text-xs text-taupe">Сообщения обновляются в реальном времени</p>
                </div>

                <div className="flex-1 space-y-2 overflow-y-auto px-1 py-3">
                  {messages.map((message) => {
                    const mine = message.author_id === authUserId;
                    return (
                      <motion.div
                        key={message.id}
                        initial={{ opacity: 0, y: 8 }}
                        animate={{ opacity: 1, y: 0 }}
                        className={cn("flex", mine ? "justify-end" : "justify-start")}
                      >
                        <div
                          className={cn(
                            "max-w-[82%] rounded-[24px] px-4 py-3",
                            mine ? "bg-ink text-white" : "bg-cream text-ink"
                          )}
                        >
                          <p className={cn("text-xs", mine ? "text-white/70" : "text-taupe")}>
                            {message.profiles?.nickname ?? "Участник"} • {formatDate(message.created_at)}
                          </p>
                          <p className="mt-1 whitespace-pre-wrap text-sm leading-6">
                            {message.content}
                          </p>
                        </div>
                      </motion.div>
                    );
                  })}
                </div>

                <div className="mt-auto flex items-center gap-2 pt-2">
                  <Input
                    placeholder="Напишите сообщение…"
                    value={messageText}
                    onChange={(e) => setMessageText(e.target.value)}
                    className="py-2.5"
                  />
                  <Button onClick={sendMessage} disabled={!messageText.trim()} className="px-3">
                    <SendHorizonal className="h-4 w-4" />
                  </Button>
                </div>
              </>
            ) : (
              <div className="flex h-full items-center justify-center text-center text-sm text-taupe">
                Выберите комнату слева или создайте новую.
              </div>
            )}
          </div>
        </div>
      </SectionCard>
    </div>
  );
}
