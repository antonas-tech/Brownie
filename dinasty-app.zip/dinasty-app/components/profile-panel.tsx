"use client";

import { Button, Input, SectionCard, Textarea } from "@/components/ui";
import { uploadFile, supabase } from "@/lib/supabase";
import { Profile } from "@/lib/types";
import Image from "next/image";
import { Camera, LogOut, ShieldCheck } from "lucide-react";
import { useState } from "react";

export function ProfilePanel({
  authUserId,
  profile,
  loading
}: {
  authUserId: string | null;
  profile: Profile | null;
  loading: boolean;
}) {
  const [mode, setMode] = useState<"login" | "register">("register");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [nickname, setNickname] = useState("");
  const [username, setUsername] = useState("");
  const [bio, setBio] = useState("");
  const [avatar, setAvatar] = useState<File | null>(null);
  const [pending, setPending] = useState(false);
  const [message, setMessage] = useState("");

  async function handleRegister() {
    setPending(true);
    setMessage("");

    const { data, error } = await supabase.auth.signUp({
      email,
      password
    });

    if (error || !data.user) {
      setPending(false);
      setMessage(error?.message ?? "Ошибка регистрации");
      return;
    }

    let avatarUrl: string | null = null;

    if (avatar) {
      avatarUrl = await uploadFile("avatars", avatar, data.user.id);
    }

    const { error: profileError } = await supabase.from("profiles").upsert({
      id: data.user.id,
      username,
      nickname,
      bio,
      avatar_url: avatarUrl
    });

    setPending(false);
    setMessage(
      profileError
        ? profileError.message
        : "Аккаунт создан. Если включено подтверждение почты — перейдите по ссылке из письма."
    );
  }

  async function handleLogin() {
    setPending(true);
    setMessage("");
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    setPending(false);
    setMessage(error?.message ?? "Вход выполнен");
  }

  async function handleLogout() {
    await supabase.auth.signOut();
  }

  if (loading) {
    return <SectionCard>Загрузка профиля…</SectionCard>;
  }

  if (!authUserId || !profile) {
    return (
      <SectionCard className="space-y-4">
        <div>
          <p className="mb-1 text-lg font-semibold">
            {mode === "register" ? "Создать семейный аккаунт" : "Войти в Dinasty"}
          </p>
          <p className="text-sm text-taupe">
            Красивое личное пространство для общения и семейных воспоминаний.
          </p>
        </div>

        <div className="grid grid-cols-2 gap-2 rounded-3xl bg-white/60 p-1">
          <Button
            variant={mode === "register" ? "primary" : "ghost"}
            onClick={() => setMode("register")}
          >
            Регистрация
          </Button>
          <Button
            variant={mode === "login" ? "primary" : "ghost"}
            onClick={() => setMode("login")}
          >
            Вход
          </Button>
        </div>

        <div className="space-y-3">
          <Input
            type="email"
            placeholder="Email / логин"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
          />
          <Input
            type="password"
            placeholder="Пароль"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
          />

          {mode === "register" && (
            <>
              <Input
                placeholder="@username"
                value={username}
                onChange={(e) => setUsername(e.target.value.toLowerCase())}
              />
              <Input
                placeholder="Nickname"
                value={nickname}
                onChange={(e) => setNickname(e.target.value)}
              />
              <Textarea
                placeholder="Немного о вашей семье"
                value={bio}
                onChange={(e) => setBio(e.target.value)}
              />
              <label className="flex cursor-pointer items-center gap-3 rounded-3xl border border-dashed border-white/80 bg-white/60 p-4 text-sm text-taupe">
                <Camera className="h-5 w-5" />
                <span>{avatar ? avatar.name : "Загрузить аватарку"}</span>
                <input
                  className="hidden"
                  type="file"
                  accept="image/*"
                  onChange={(e) => setAvatar(e.target.files?.[0] ?? null)}
                />
              </label>
            </>
          )}
        </div>

        <Button onClick={mode === "register" ? handleRegister : handleLogin} disabled={pending}>
          {pending ? "Подождите…" : mode === "register" ? "Создать аккаунт" : "Войти"}
        </Button>

        {message && <p className="text-sm text-taupe">{message}</p>}
      </SectionCard>
    );
  }

  return (
    <SectionCard className="space-y-4">
      <div className="flex items-center gap-4">
        <div className="relative h-20 w-20 overflow-hidden rounded-[28px] bg-white/80">
          {profile.avatar_url ? (
            <Image
              src={profile.avatar_url}
              alt={profile.nickname}
              fill
              className="object-cover"
              sizes="80px"
            />
          ) : null}
        </div>
        <div className="min-w-0 flex-1">
          <div className="mb-1 flex items-center gap-2">
            <p className="truncate text-xl font-semibold">{profile.nickname}</p>
            <ShieldCheck className="h-4 w-4 text-accent" />
          </div>
          <p className="text-sm text-taupe">@{profile.username}</p>
          <p className="mt-2 text-sm leading-6 text-ink/80">{profile.bio || "Семейный профиль."}</p>
        </div>
      </div>

      <div className="rounded-[28px] bg-white/60 p-4">
        <p className="text-sm text-taupe">ID аккаунта</p>
        <p className="mt-1 break-all text-sm">{profile.id}</p>
      </div>

      <Button variant="secondary" onClick={handleLogout} className="w-full gap-2">
        <LogOut className="h-4 w-4" />
        Выход
      </Button>
    </SectionCard>
  );
}
