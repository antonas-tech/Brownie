create extension if not exists "pgcrypto";

create table if not exists public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  username text not null unique,
  nickname text not null,
  bio text,
  avatar_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 5000),
  image_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.comments (
  id uuid primary key default gen_random_uuid(),
  post_id uuid not null references public.posts(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 2000),
  created_at timestamptz not null default now()
);

create table if not exists public.stories (
  id uuid primary key default gen_random_uuid(),
  author_id uuid not null references public.profiles(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 180),
  body text not null check (char_length(body) between 1 and 10000),
  image_url text,
  created_at timestamptz not null default now()
);

create table if not exists public.chat_rooms (
  id uuid primary key default gen_random_uuid(),
  title text not null check (char_length(title) between 1 and 180),
  is_group boolean not null default true,
  created_by uuid not null references public.profiles(id) on delete cascade,
  created_at timestamptz not null default now()
);

create table if not exists public.chat_room_members (
  room_id uuid not null references public.chat_rooms(id) on delete cascade,
  user_id uuid not null references public.profiles(id) on delete cascade,
  joined_at timestamptz not null default now(),
  primary key (room_id, user_id)
);

create table if not exists public.messages (
  id uuid primary key default gen_random_uuid(),
  room_id uuid not null references public.chat_rooms(id) on delete cascade,
  author_id uuid not null references public.profiles(id) on delete cascade,
  content text not null check (char_length(content) between 1 and 5000),
  created_at timestamptz not null default now()
);

create index if not exists idx_posts_created_at on public.posts(created_at desc);
create index if not exists idx_comments_post_id on public.comments(post_id);
create index if not exists idx_stories_created_at on public.stories(created_at desc);
create index if not exists idx_room_members_user_id on public.chat_room_members(user_id);
create index if not exists idx_messages_room_id_created_at on public.messages(room_id, created_at);

alter table public.profiles enable row level security;
alter table public.posts enable row level security;
alter table public.comments enable row level security;
alter table public.stories enable row level security;
alter table public.chat_rooms enable row level security;
alter table public.chat_room_members enable row level security;
alter table public.messages enable row level security;

drop policy if exists "profiles_select_authenticated" on public.profiles;
create policy "profiles_select_authenticated" on public.profiles for select to authenticated using (true);
drop policy if exists "profiles_insert_self" on public.profiles;
create policy "profiles_insert_self" on public.profiles for insert to authenticated with check (auth.uid() = id);
drop policy if exists "profiles_update_self" on public.profiles;
create policy "profiles_update_self" on public.profiles for update to authenticated using (auth.uid() = id) with check (auth.uid() = id);

drop policy if exists "posts_select_authenticated" on public.posts;
create policy "posts_select_authenticated" on public.posts for select to authenticated using (true);
drop policy if exists "posts_insert_self" on public.posts;
create policy "posts_insert_self" on public.posts for insert to authenticated with check (auth.uid() = author_id);
drop policy if exists "posts_update_own" on public.posts;
create policy "posts_update_own" on public.posts for update to authenticated using (auth.uid() = author_id) with check (auth.uid() = author_id);
drop policy if exists "posts_delete_own" on public.posts;
create policy "posts_delete_own" on public.posts for delete to authenticated using (auth.uid() = author_id);

drop policy if exists "comments_select_authenticated" on public.comments;
create policy "comments_select_authenticated" on public.comments for select to authenticated using (true);
drop policy if exists "comments_insert_self" on public.comments;
create policy "comments_insert_self" on public.comments for insert to authenticated with check (auth.uid() = author_id);
drop policy if exists "comments_update_own" on public.comments;
create policy "comments_update_own" on public.comments for update to authenticated using (auth.uid() = author_id) with check (auth.uid() = author_id);
drop policy if exists "comments_delete_own" on public.comments;
create policy "comments_delete_own" on public.comments for delete to authenticated using (auth.uid() = author_id);

drop policy if exists "stories_select_authenticated" on public.stories;
create policy "stories_select_authenticated" on public.stories for select to authenticated using (true);
drop policy if exists "stories_insert_self" on public.stories;
create policy "stories_insert_self" on public.stories for insert to authenticated with check (auth.uid() = author_id);
drop policy if exists "stories_update_own" on public.stories;
create policy "stories_update_own" on public.stories for update to authenticated using (auth.uid() = author_id) with check (auth.uid() = author_id);
drop policy if exists "stories_delete_own" on public.stories;
create policy "stories_delete_own" on public.stories for delete to authenticated using (auth.uid() = author_id);

drop policy if exists "chat_rooms_select_members" on public.chat_rooms;
create policy "chat_rooms_select_members" on public.chat_rooms for select to authenticated using (
  exists (
    select 1 from public.chat_room_members crm
    where crm.room_id = chat_rooms.id and crm.user_id = auth.uid()
  )
);
drop policy if exists "chat_rooms_insert_creator" on public.chat_rooms;
create policy "chat_rooms_insert_creator" on public.chat_rooms for insert to authenticated with check (auth.uid() = created_by);
drop policy if exists "chat_rooms_update_creator" on public.chat_rooms;
create policy "chat_rooms_update_creator" on public.chat_rooms for update to authenticated using (auth.uid() = created_by) with check (auth.uid() = created_by);
drop policy if exists "chat_rooms_delete_creator" on public.chat_rooms;
create policy "chat_rooms_delete_creator" on public.chat_rooms for delete to authenticated using (auth.uid() = created_by);

drop policy if exists "members_select_same_room" on public.chat_room_members;
create policy "members_select_same_room" on public.chat_room_members for select to authenticated using (
  auth.uid() = user_id
  or exists (
    select 1 from public.chat_room_members me
    where me.room_id = chat_room_members.room_id and me.user_id = auth.uid()
  )
);
drop policy if exists "members_insert_by_room_creator_or_self" on public.chat_room_members;
create policy "members_insert_by_room_creator_or_self" on public.chat_room_members for insert to authenticated with check (
  auth.uid() = user_id
  or exists (
    select 1 from public.chat_rooms r
    where r.id = chat_room_members.room_id and r.created_by = auth.uid()
  )
);
drop policy if exists "members_delete_creator_or_self" on public.chat_room_members;
create policy "members_delete_creator_or_self" on public.chat_room_members for delete to authenticated using (
  auth.uid() = user_id
  or exists (
    select 1 from public.chat_rooms r
    where r.id = chat_room_members.room_id and r.created_by = auth.uid()
  )
);

drop policy if exists "messages_select_members" on public.messages;
create policy "messages_select_members" on public.messages for select to authenticated using (
  exists (
    select 1 from public.chat_room_members crm
    where crm.room_id = messages.room_id and crm.user_id = auth.uid()
  )
);
drop policy if exists "messages_insert_members" on public.messages;
create policy "messages_insert_members" on public.messages for insert to authenticated with check (
  auth.uid() = author_id
  and exists (
    select 1 from public.chat_room_members crm
    where crm.room_id = messages.room_id and crm.user_id = auth.uid()
  )
);
drop policy if exists "messages_update_own" on public.messages;
create policy "messages_update_own" on public.messages for update to authenticated using (auth.uid() = author_id) with check (auth.uid() = author_id);
drop policy if exists "messages_delete_own" on public.messages;
create policy "messages_delete_own" on public.messages for delete to authenticated using (auth.uid() = author_id);

insert into storage.buckets (id, name, public) values ('avatars', 'avatars', true) on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('posts', 'posts', true) on conflict (id) do nothing;
insert into storage.buckets (id, name, public) values ('stories', 'stories', true) on conflict (id) do nothing;

drop policy if exists "avatars_public_read" on storage.objects;
create policy "avatars_public_read" on storage.objects for select to public using (bucket_id = 'avatars');
drop policy if exists "avatars_auth_upload" on storage.objects;
create policy "avatars_auth_upload" on storage.objects for insert to authenticated with check (bucket_id = 'avatars');
drop policy if exists "posts_public_read" on storage.objects;
create policy "posts_public_read" on storage.objects for select to public using (bucket_id = 'posts');
drop policy if exists "posts_auth_upload" on storage.objects;
create policy "posts_auth_upload" on storage.objects for insert to authenticated with check (bucket_id = 'posts');
drop policy if exists "stories_public_read" on storage.objects;
create policy "stories_public_read" on storage.objects for select to public using (bucket_id = 'stories');
drop policy if exists "stories_auth_upload" on storage.objects;
create policy "stories_auth_upload" on storage.objects for insert to authenticated with check (bucket_id = 'stories');
