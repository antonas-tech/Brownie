export type Profile = {
  id: string;
  username: string;
  nickname: string;
  avatar_url: string | null;
  bio: string | null;
  created_at: string;
};

export type Post = {
  id: string;
  author_id: string;
  content: string;
  image_url: string | null;
  created_at: string;
  profiles: Profile | null;
  comments?: CommentItem[];
};

export type CommentItem = {
  id: string;
  post_id: string;
  author_id: string;
  content: string;
  created_at: string;
  profiles: Profile | null;
};

export type StoryItem = {
  id: string;
  author_id: string;
  title: string;
  body: string;
  image_url: string | null;
  created_at: string;
  profiles: Profile | null;
};

export type ChatRoom = {
  id: string;
  title: string;
  is_group: boolean;
  created_by: string;
  created_at: string;
};

export type MessageItem = {
  id: string;
  room_id: string;
  author_id: string;
  content: string;
  created_at: string;
  profiles: Profile | null;
};
